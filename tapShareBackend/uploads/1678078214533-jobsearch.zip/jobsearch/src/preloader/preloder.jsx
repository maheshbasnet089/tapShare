import React from 'react'

const preloder = () => {
    return (
        <div >
            <img src='https://mir-s3-cdn-cf.behance.net/project_modules/disp/8a1f1813765711.56277edb36b94.gif' className='h-[100vh] w-[100%]' />

        </div>
    )
}

export default preloder