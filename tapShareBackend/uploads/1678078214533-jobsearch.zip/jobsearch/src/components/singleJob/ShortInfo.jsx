// import React from 'react'
// import { BsFillFilePostFill, BsFillPersonCheckFill, BsFillKeyboardFill } from 'react-icons/bs'
// import { FaIndustry } from 'react-icons/fa'
// import { AiOutlineBarChart } from 'react-icons/ai'



// const ShortInfo = () => {
//     return (
     
//     )
// }

// export default ShortInfo
